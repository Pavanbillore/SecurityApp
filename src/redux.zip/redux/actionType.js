export const INCREMENT = 'INCREMENT';
export const DECREMENT = 'DECREMENT';
export const NAME = 'NAME';
export const PHONE = 'PHONE';
export const EMAIL = 'EMAIL';
export const GENDER = 'GENDER';
export const ADDRESS = 'ADDRESS';
export const FETCH_DATA = 'fetch_data';

